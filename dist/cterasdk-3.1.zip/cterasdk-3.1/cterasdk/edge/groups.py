from ..common import Object

from ..exception import CTERAException, InputError

from .enum import PrincipalType

import logging

def add_members(ctera_host, group, new_members):
    
    current_members = ctera_host.get('/config/auth/groups/' + group + '/members')
    
    new_member_dict = {}
    
    for new_member in new_members:
        
        if len(new_member) != 2:
            
            raise InputError('Invalid input', repr(entry), '[("type", "name"), ...]')
        
        new_member_type, new_member_name = new_member
        
        new_member_type, new_member = member(new_member_type, new_member_name)
        
        new_member_dict[new_member_type + '#' + new_member_name] = new_member
        
    for current_member in current_members:
        
        current_member_type = current_member._classname
        
        current_member_name = None
        
        if current_member_type in [PrincipalType.LU, PrincipalType.LG]:
            
            current_member_name = current_member.ref
            
            current_member_name = current_member_name[current_member_name.rfind('#') + 1 :]
            
        else:
            
            current_member_name = current_member.name
        
        current_member_key = current_member_type + '#' + current_member_name
        
        if not current_member_key in new_member_dict:
            
            new_member_dict[current_member_key] = current_member
            
    members = [v for k,v in new_member_dict.items()]
    
    logging.getLogger().info('Adding group members. {0}'.format({'group' : group}))
    
    ctera_host.put('/config/auth/groups/' + group + '/members', members)
    
    logging.getLogger().info('Group members added. {0}'.format({'group' : group}))
    
def remove_members(ctera_host, group, tuples):
    
    current_members = ctera_host.get('/config/auth/groups/' + group + '/members')
    
    options = {v : k for k,v in PrincipalType.__dict__.items() if not k.startswith('_')} # reverse
    
    members = []
    
    for current_member in current_members:
        
        current_member_type = current_member._classname
        
        current_member_name = None
        
        if current_member_type in [PrincipalType.LU, PrincipalType.LG]:
            
            current_member_name = current_member.ref
            
            current_member_name = current_member_name[current_member_name.rfind('#') + 1 :]
            
        else:
            
            current_member_name = current_member.name
        
        if not (options.get(current_member_type), current_member_name) in tuples:
            
            members.append(current_member)
            
    logging.getLogger().info('Removing group members. {0}'.format({'group' : group}))

    ctera_host.put('/config/auth/groups/' + group + '/members', members)
    
    logging.getLogger().info('Group members removed. {0}'.format({'group' : group}))
    
def member(type, name):
    
    options = {k : v for k,v in PrincipalType.__dict__.items() if not k.startswith('_')}
    
    member = Object()
        
    member_type = options.get(type)
    
    if member_type == PrincipalType.LU:

        member._classname = PrincipalType.LU

        member.ref = "#config#auth#users#" + name

    elif member_type == PrincipalType.LG:

        member._classname = PrincipalType.LG

        member.ref = "#config#auth#groups#" + name

    elif member_type == PrincipalType.DU:

        member._classname = PrincipalType.DU

        member.name = name

    elif member_type == PrincipalType.DG:

        member._classname = PrincipalType.DG

        member.name = name
        
    else:
        
        raise InputError('Invalid principal type', type, list(options.keys()))
        
    return member_type, member