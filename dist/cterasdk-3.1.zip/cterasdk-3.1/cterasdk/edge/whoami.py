def whoami(CTERAHost):
    
    session = CTERAHost.session()
        
    print(session)