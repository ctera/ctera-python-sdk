## Building

Create a source distribution

```bash
python -B setup.py sdist --formats=tar,gztar,zip
```
