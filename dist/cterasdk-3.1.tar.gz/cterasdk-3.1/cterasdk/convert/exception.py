class ParseException(Exception):

	pass