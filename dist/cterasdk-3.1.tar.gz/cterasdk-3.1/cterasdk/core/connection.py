import logging

def test(CTERAHost):
    
    test_network(CTERAHost)
    
def test_network(CTERAHost):
    
    CTERAHost.test_conn()